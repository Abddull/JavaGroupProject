package com.example.demo;

public class ValidationGroups {
	
	public interface Register{
	}
	
	public interface Login{
	}
	
	public interface CreateCruise{
	}
	
	public interface EditCruise{
	}
}
