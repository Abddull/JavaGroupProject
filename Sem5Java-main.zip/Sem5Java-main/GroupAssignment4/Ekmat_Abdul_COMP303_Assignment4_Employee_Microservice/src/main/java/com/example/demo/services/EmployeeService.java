package com.example.demo.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.demo.Employee;
import com.example.demo.repos.EmployeeRepository;

@Service
public class EmployeeService {
	
	@Autowired
	EmployeeRepository empRepo;
	
	public Employee addEmployee(Employee emp){
		return empRepo.save(emp);
	}

	public Employee getEmployeeById(int id) {
		 return empRepo.findById(id).get();
	}
	
	public Employee getEmployeeByUsername(String username) {
		return empRepo.findByUsername(username);
	}
}
