package com.example.demo.repos;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.example.demo.Cruise;

public interface CruiseRepository extends JpaRepository<Cruise, Integer>{

	@Query ("delete Cruise b where b.cruiseId = :id ") 
	void cancelCruiseById(@Param("id") int bookingId);
}
