package com.example.demo.controllers;

import java.time.LocalDate;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;
import com.example.demo.Cruise;
import com.example.demo.Employee;
import com.example.demo.ValidationGroups;
import com.example.demo.services.CruiseService;

@RestController
public class CruiseController {

	@Autowired
    CruiseService cruiseService;
    
    @RequestMapping(value = "/cruises", method = RequestMethod.GET)
	public ModelAndView getCruises(HttpSession session) {
		ModelAndView model = new ModelAndView("cruise");
		session.removeAttribute("successMsg");
		session.removeAttribute("errorMsg");
		
		Object customerObject = session.getAttribute("customer");
		if (!(customerObject instanceof Employee)) {
			model.setViewName("index");	
		}
		session.setAttribute("cruises", cruiseService.getAllCruises());
		return model;
	}
    
    // Add a new Cruise
    @PostMapping("/create")
    public String createCruise(@Validated(ValidationGroups.CreateCruise.class) Cruise cruise, BindingResult result, HttpServletRequest request, Model model) {
    	if(result.hasErrors()) {
			return "create";
		}
		
		cruise = cruiseService.createCruise(cruise);
		return "redirect:details";
    }
    
    // Open Update Cruise details page
    @RequestMapping("/editcruise")
	public String editCruise(@RequestParam("cruiseId")int cruiseId, HttpSession session, Model model) {
		if (cruiseId == 0) {
			return "cruises";
		}
		
		Cruise cruise = cruiseService.findById(cruiseId);
		model.addAttribute("cruise", cruise);
		return "edit-cruise";
	}
    
    // Update Cruise details
    @PostMapping("/updateprofile")
    public String updateCruise(@Validated(ValidationGroups.EditCruise.class) Cruise updatedCruise, BindingResult result, HttpServletRequest request, HttpSession session) {
    	if(result.hasErrors()) {
			return "cruises";
		}
    	
		Object cruiseObject = session.getAttribute("cruise");
		if (!(cruiseObject instanceof Cruise)) {
			return "cruises";
		}
		
		Cruise oldCruise = (Cruise)cruiseObject;
		oldCruise = cruiseService.findById(oldCruise.getCruiseId());
		
		updatedCruise.setCruiseId(oldCruise.getCruiseId());
		cruiseService.updateCruise(updatedCruise);
		return "cruises";
    }
    
    @RequestMapping(value = "/delete/{cruiseId}", method = RequestMethod.DELETE)
	public String deleteCruise(@PathVariable("cruiseId") int id, HttpSession session) {
		Cruise cruise = cruiseService.findById(id);
		LocalDate departure = cruise.getDepartureDate().toLocalDate();
		
		if (LocalDate.now().isAfter(departure)) {
			cruiseService.deleteCruiseById(id);
			session.setAttribute("successMsg", "The cruise has been cancelled.");
		} else {
			session.setAttribute("errorMsg", "You must cancel cruise 7 days in adavance");
		}
		return "redirect:/history";
	}
}
