package com.example.demo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;
import com.example.demo.ValidationGroups.Login;
import com.example.demo.ValidationGroups.Register;

@Entity
@Table(name="employee")
public class Employee {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="employeeid")
	public int EmployeeId;
	
	@Column(name="name")
	@NotBlank(groups = ValidationGroups.Register.class, message = "Name cannot be empty")
	public String name;
	
	@Column(name="username")
	@NotBlank(groups = { ValidationGroups.Register.class, ValidationGroups.Login.class }, message = "Username cannot be empty")
	public String username;
	
	@Column(name="password")
	@NotBlank(groups = { ValidationGroups.Register.class, ValidationGroups.Login.class }, message = "Password cannot be empty")
	public String password;

	public Employee() {}
	
	public Employee(int employeeId, @NotBlank(groups = Register.class, message = "Name cannot be empty") String name,
			@NotBlank(groups = { Register.class, Login.class }, message = "Username cannot be empty") String username,
			@NotBlank(groups = { Register.class, Login.class }, message = "Password cannot be empty") String password) {
		super();
		EmployeeId = employeeId;
		this.name = name;
		this.username = username;
		this.password = password;
	}

	public int getEmployeeId() {
		return EmployeeId;
	}

	public void setEmployeeId(int employeeId) {
		EmployeeId = employeeId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
	
	
}
