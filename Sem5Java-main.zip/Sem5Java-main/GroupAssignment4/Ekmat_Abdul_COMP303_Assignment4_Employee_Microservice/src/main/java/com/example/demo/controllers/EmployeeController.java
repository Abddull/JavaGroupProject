package com.example.demo.controllers;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import com.example.demo.Employee;
import com.example.demo.ValidationGroups;
import com.example.demo.services.EmployeeService;

@RestController
public class EmployeeController {
	
	@Autowired
    EmployeeService cusService;

    // Open landing/login/register page
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String index(Employee employee) {
		return "index";
	}
    
    // Check Login credentials for customer
    @GetMapping("/login")
    public String login(@Validated(ValidationGroups.Login.class) Employee loggingEmployee, BindingResult result, Model model, HttpServletRequest request) {
    	if (result.hasErrors()) {
			return "index";
		}
    	Employee employee = cusService.getEmployeeByUsername(loggingEmployee.getUsername());
		if (employee == null || employee.getPassword().equals(loggingEmployee.getPassword())) {
			model.addAttribute("errorMsg", "Invalid credentials");
			return "index";
		}
		HttpSession session = request.getSession();
		session.setAttribute("employee", employee);
		return "redirect:/history";
    }

    // Logs out current user
	@GetMapping(value = "/logout")
	public String logout(Employee employee, HttpSession session) {
		session.removeAttribute("employee");
		return "index";
	}

    // Add a new Customer
    @PostMapping("/register")
    public String register(@Validated(ValidationGroups.Register.class)  Employee emp, BindingResult result, HttpServletRequest request, Model model) {
    	if(result.hasErrors()) {
			return "register";
		}
		
		emp = cusService.addEmployee(emp);
		HttpSession session = request.getSession();
		session.setAttribute("employee", emp);
		return "redirect:history";
    }
}
