package com.jpa.cloud;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.server.EnableEurekaServer;

@EnableEurekaServer
@SpringBootApplication
public class SpringBootJpaCloudServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootJpaCloudServerApplication.class, args);
		System.out.println("Spring Boot Eureka server started");
	}

}
