package com.example.demo;

import java.util.Date;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.joda.time.DateTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class BookingController {
	
	@Autowired
    BookingRepository bookRepository;
	@Autowired
    CruiseRepository cruRepository;
	
	// Get All Bookings
    @GetMapping("/bookings")
    public List<Booking> getAllBookings() {
        return bookRepository.findAll();
    }
    
    // Get Booking using the given Id
    @GetMapping("/booking/{id}")
    public Optional<Booking> getBooking(@PathVariable("id") int id) {
        return bookRepository.findById(id);
    }
    
    // Get Bookings using the given customer Id
    @GetMapping("/bookings/{id}")
    public List<Booking> getCustomerBookings(@PathVariable("id") int id) {
    	List<Booking> bookings = bookRepository.findAll();
    	List<Booking> customerBookings = new ArrayList<Booking>();
    	for (Booking booking : bookings) {
    		if (booking.getBookingId() == id)
    			customerBookings.add(booking);
    	}
        return customerBookings;
    }

    // Add a new booking
    @PostMapping("/booking")
    public Booking addBooking(@Validated @RequestBody Booking book) {
        return bookRepository.save(book);
    }
    
    // Update existing booking details
    @PostMapping("/booking/{cusId}")
    public Booking updateBooking(@PathVariable("id") int id, @Validated @RequestBody Booking book) {
    	Optional<Cruise> cruiseSearch = cruRepository.findById(book.getCruiseId());
    	Cruise cruise;
    	if (!cruiseSearch.isPresent())
    		return null;
    	
    	cruise = cruiseSearch.get();
    	if (!cruise.getDepartureDate().before(DateTime.now().minusDays(7).toDate())) 
    		return null;
    	
    	book.setBookingId(id);
    	return bookRepository.save(book);
    }
}
