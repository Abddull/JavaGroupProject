package com.example.demo;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="cruise")
public class Cruise {
	@Id
	@Column(name="cruiseid")
	public int cruiseId;
	
	@Column(name="cruisename")
	public String cruiseName;
	
	@Column(name="departuredate")
	public Date departureDate;
	
	@Column(name="duration")
	public String duration;
	
	@Column(name="price")
	public double price;
	
	public Cruise() {}

	public Cruise(int cruiseId, String cruiseName, Date departureDate, String duration, double price) {
		super();
		this.cruiseId = cruiseId;
		this.cruiseName = cruiseName;
		this.departureDate = departureDate;
		this.duration = duration;
		this.price = price;
	}

	public int getCruiseId() {
		return cruiseId;
	}

	public void setCruiseId(int cruiseId) {
		this.cruiseId = cruiseId;
	}

	public String getCruiseName() {
		return cruiseName;
	}

	public void setCruiseName(String cruiseName) {
		this.cruiseName = cruiseName;
	}

	public Date getDepartureDate() {
		return departureDate;
	}

	public void setDepartureDate(Date departureDate) {
		this.departureDate = departureDate;
	}

	public String getDuration() {
		return duration;
	}

	public void setDuration(String duration) {
		this.duration = duration;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}
	
	
}
