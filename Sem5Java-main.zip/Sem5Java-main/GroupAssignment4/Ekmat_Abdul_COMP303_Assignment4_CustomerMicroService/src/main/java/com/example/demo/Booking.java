package com.example.demo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="customer")
public class Booking {

	@Id
	@Column(name="bookingid")
	private int bookingId;
	
	@Column(name="customerId")
	private int customerId;
	
	@Column(name="cruiseid")
	private int cruiseId;
	
	@Column(name="numberofguests")
	private int numberOfGuests;
	
	@Column(name="totalamount")
	private double totalAmount;
	
	@Column(name="status")
	private String status;

	public Booking() {}
	
	public Booking(int bookingId, int customerId, int cruiseId, int numberOfGuests, double totalAmount, String status) {
		super();
		this.bookingId = bookingId;
		this.customerId = customerId;
		this.cruiseId = cruiseId;
		this.numberOfGuests = numberOfGuests;
		this.totalAmount = totalAmount;
		this.status = status;
	}

	
	public int getBookingId() {
		return bookingId;
	}

	public void setBookingId(int bookingId) {
		this.bookingId = bookingId;
	}

	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public int getCruiseId() {
		return cruiseId;
	}

	public void setCruiseId(int cruiseId) {
		this.cruiseId = cruiseId;
	}

	public int getNumberOfGuests() {
		return numberOfGuests;
	}

	public void setNumberOfGuests(int numberOfGuests) {
		this.numberOfGuests = numberOfGuests;
	}

	public double getTotalAmount() {
		return totalAmount;
	}

	public void setTotalAmount(double totalAmount) {
		this.totalAmount = totalAmount;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
	
	
}
