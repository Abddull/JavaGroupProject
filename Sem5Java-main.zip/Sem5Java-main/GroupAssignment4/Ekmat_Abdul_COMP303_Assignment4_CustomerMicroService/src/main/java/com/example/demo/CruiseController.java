package com.example.demo;

import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class CruiseController {

	@Autowired
    CruiseRepository cruRepository;
	
	// Get All Cruises
    @GetMapping("/cruises")
    public List<Cruise> getAllCruises() {
        return cruRepository.findAll();
    }
    
    // Get Cruise using the given Id
    @GetMapping("/cruise/{id}")
    public Optional<Cruise> getCruise(@PathVariable("id") int id) {
        return cruRepository.findById(id);
    }
}
