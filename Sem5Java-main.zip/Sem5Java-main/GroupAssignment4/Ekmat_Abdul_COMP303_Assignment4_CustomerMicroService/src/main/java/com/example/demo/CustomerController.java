package com.example.demo;

import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class CustomerController {
	
	@Autowired
    CustomerRepository cusRepository;
	
	// Get All Customers
    @GetMapping("/customers")
    public List<Customer> getAllCustomers() {
        return cusRepository.findAll();
    }
    
    // Get Customer using the given Id
    @GetMapping("/customer/{id}")
    public Optional<Customer> getCustomers(@PathVariable("id") int id) {
        return cusRepository.findById(id);
    }
    
    // Check Login credentials for customer
    @GetMapping("/customer/login/{username}/{password}")
    public Customer addEmployee(@PathVariable("username") String username, @PathVariable("password") String password) {
    	List<Customer> customers = cusRepository.findAll();
    	for (Customer customer : customers) {
    		if (customer.getUsername().equals(username) && customer.getPassword().equals(password))
    			return customer;
    	}
        return null;
    }

    // Add a new Customer
    @PostMapping("/customer")
    public Customer addEmployee(@Validated @RequestBody Customer cus) {
        return cusRepository.save(cus);
    }
    
    // Update Customer details
    @PostMapping("/customer/{cusId}")
    public Customer updateCustomer(@PathVariable("id") int id, @Validated @RequestBody Customer cus) {
    	cus.setCustomerId(id);
    	return cusRepository.save(cus);
    }
}
