package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@EnableEurekaClient
@SpringBootApplication
public class EkmatAbdulComp303Assignment4CustomerMicroServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(EkmatAbdulComp303Assignment4CustomerMicroServiceApplication.class, args);
		System.out.println("Customer MicroService started.");
	}

}
