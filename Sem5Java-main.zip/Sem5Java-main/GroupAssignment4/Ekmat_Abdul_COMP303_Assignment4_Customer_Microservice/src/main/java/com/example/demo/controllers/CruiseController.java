package com.example.demo.controllers;

import javax.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;
import com.example.demo.Booking;
import com.example.demo.Customer;
import com.example.demo.services.CruiseService;

@RestController
public class CruiseController {

	@Autowired
    CruiseService cruiseService;
    
    @RequestMapping(value = "/cruises", method = RequestMethod.GET)
	public ModelAndView getCruises(HttpSession session) {
		ModelAndView model = new ModelAndView("cruise");
		session.removeAttribute("successMsg");
		session.removeAttribute("errorMsg");
		
		Object customerObject = session.getAttribute("customer");
		if (!(customerObject instanceof Customer)) {
			model.setViewName("index");	
		}
		session.setAttribute("cruises", cruiseService.getAllCruises());
		return model;
	}
}
