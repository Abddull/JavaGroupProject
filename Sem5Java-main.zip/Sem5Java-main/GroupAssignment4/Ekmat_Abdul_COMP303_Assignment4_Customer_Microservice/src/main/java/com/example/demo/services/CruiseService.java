package com.example.demo.services;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.demo.Cruise;
import com.example.demo.repos.CruiseRepository;

@Service
public class CruiseService {
	
	@Autowired
	CruiseRepository cruiseRepo;
	
	public List<Cruise> getAllCruises(){
		return cruiseRepo.findAll();
	}
	
	public Cruise findById(int id) {
		return cruiseRepo.findById(id).get();
	}
}
