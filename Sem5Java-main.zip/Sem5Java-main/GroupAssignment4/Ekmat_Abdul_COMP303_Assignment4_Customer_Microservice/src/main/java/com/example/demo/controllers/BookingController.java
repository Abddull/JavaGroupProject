package com.example.demo.controllers;

import java.time.LocalDate;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;
import com.example.demo.Booking;
import com.example.demo.Cruise;
import com.example.demo.Customer;
import com.example.demo.ValidationGroups;
import com.example.demo.services.BookingService;
import com.example.demo.services.CruiseService;

@RestController
public class BookingController {
	
	@Autowired
    BookingService bookService;
	@Autowired
    CruiseService cruiseService;
	
	// Get Bookings for logged customer
    @GetMapping("/history")
    public ModelAndView getCustomerBookings(HttpSession session, HttpServletRequest request) {
    	ModelAndView mv = new ModelAndView("history");
		session.removeAttribute("successMsg");
		session.removeAttribute("errorMsg");
		Object customerObject = session.getAttribute("customer");
		
		if (!(customerObject instanceof Customer)) {
			mv.setViewName("index");
			return mv;
		}
		
		Customer customer = (Customer) customerObject;
		List<Booking> bookings = bookService.findByCustomerId(customer.getCustomerId());
		mv.addObject("bookings", bookings);
		return mv;
    }
    
    @RequestMapping(value = "/bookings", method = RequestMethod.POST)
	public String addBooking(@Validated(ValidationGroups.ReserveCruise.class) Booking booking, BindingResult result, HttpServletRequest request, HttpSession session, Model model) {
		if (result.hasErrors()) {
			model.addAttribute("errorCruiseId", booking.getCruiseId());
			return "cruise";
		}
		
		Cruise cruise = cruiseService.findById(booking.getCruiseId());
		LocalDate startDate1 = cruise.getDepartureDate().toLocalDate();
		LocalDate endDate1 = cruise.getReturnDate().toLocalDate();
		Object customerObject = session.getAttribute("customer");
		
		if (!(customerObject instanceof Customer))
			return "index";
		
		Customer cust = (Customer) customerObject;
		List<Booking> reservedBookings = bookService.findReservedByCustomerId(cust.getCustomerId());
		for (Booking currentBooking : reservedBookings) {
			Cruise currentCruise = cruiseService.findById(currentBooking.getCruiseId());
			LocalDate startDate2 = currentCruise.getDepartureDate().toLocalDate();
			LocalDate endDate2 = currentCruise.getReturnDate().toLocalDate();
			
			if ((startDate1.isBefore(endDate2) && startDate2.isBefore(endDate1))) {
				session.setAttribute("errorMsg", "Departure Date of Cruise " + cruise.getCruiseName() + " is overlapped with " + currentCruise.getCruiseName());
				return "redirect:/cruises";
			}
		}
		booking.setTotalAmount(booking.getNumberOfGuests() * cruise.getPrice());
		booking.setStatus("Reserved");
		bookService.addBooking(booking);
		session.setAttribute("successMsg", "You have successfully reserved your tickets for the " + cruise.getCruiseName() + " cruise!");
		return "redirect:/cruises";
	}
    
    @RequestMapping(value = "/booking/{bookingId}", method = RequestMethod.PUT)
	public String cancelBooking(@PathVariable("bookingId") int id, HttpSession session) {
    	Booking booking = bookService.findById(id);
		Cruise cruise = cruiseService.findById(booking.getCruiseId());
		
		if (LocalDate.now().minusDays(7).isBefore(cruise.getDepartureDate().toLocalDate())) {
			bookService.cancelBookingById(id);
			session.setAttribute("successMsg", "Your booking has been cancelled.");
		} else {
			session.setAttribute("errorMsg", "You must cancel cruise 7 days in adavance");
		}
		return "redirect:/history";
	}
    
	/*
	 * // Get Booking using the given Id
	 * 
	 * @GetMapping("/booking/{id}") public Optional<Booking>
	 * getBooking(@PathVariable("id") int id) { return bookService.findById(id); }
	 * 
	 * // Get Bookings using the given customer Id
	 * 
	 * @GetMapping("/bookings/{id}") public List<Booking>
	 * getCustomerBookings(@PathVariable("id") int id) { List<Booking> bookings =
	 * bookService.findAll(); List<Booking> customerBookings = new
	 * ArrayList<Booking>(); for (Booking booking : bookings) { if
	 * (booking.getBookingId() == id) customerBookings.add(booking); } return
	 * customerBookings; }
	 * 
	 * // Add a new booking
	 * 
	 * @PostMapping("/booking") public Booking addBooking(@Validated @RequestBody
	 * Booking book) { return bookService.save(book); }
	 * 
	 * // Update existing booking details
	 * 
	 * @PostMapping("/booking/{cusId}") public Booking
	 * updateBooking(@PathVariable("id") int id, @Validated @RequestBody Booking
	 * book) { Optional<Cruise> cruiseSearch =
	 * cruiseService.findById(book.getCruiseId()); Cruise cruise; if
	 * (!cruiseSearch.isPresent()) return null;
	 * 
	 * cruise = cruiseSearch.get();
	 * 
	 * if (!cruise.getDepartureDate().before(DateTime.now().minusDays(7).toDate()))
	 * return null;
	 * 
	 * book.setBookingId(id); return bookService.save(book); }
	 */
}
