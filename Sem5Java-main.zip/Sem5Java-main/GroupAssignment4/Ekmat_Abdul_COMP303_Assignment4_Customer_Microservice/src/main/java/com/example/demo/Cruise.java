package com.example.demo;

import java.sql.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="cruise")
public class Cruise {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="cruiseid")
	public int cruiseId;
	
	@Column(name="cruisename")
	public String cruiseName;
	
	@Column(name="departuredate")
	public Date departureDate;
	
	@Column(name="returndate")
	public Date returnDate;
	
	@Column(name="price")
	public double price;
	
	public Cruise() {}

	public Cruise(int cruiseId, String cruiseName, Date departureDate, Date returnDate, double price) {
		super();
		this.cruiseId = cruiseId;
		this.cruiseName = cruiseName;
		this.departureDate = departureDate;
		this.returnDate = returnDate;
		this.price = price;
	}

	public int getCruiseId() {
		return cruiseId;
	}

	public void setCruiseId(int cruiseId) {
		this.cruiseId = cruiseId;
	}

	public String getCruiseName() {
		return cruiseName;
	}

	public void setCruiseName(String cruiseName) {
		this.cruiseName = cruiseName;
	}

	public Date getDepartureDate() {
		return departureDate;
	}

	public void setDepartureDate(Date departureDate) {
		this.departureDate = departureDate;
	}

	public Date getReturnDate() {
		return returnDate;
	}

	public void setReturnDate(Date returnDate) {
		this.returnDate = returnDate;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}
	
	
}
