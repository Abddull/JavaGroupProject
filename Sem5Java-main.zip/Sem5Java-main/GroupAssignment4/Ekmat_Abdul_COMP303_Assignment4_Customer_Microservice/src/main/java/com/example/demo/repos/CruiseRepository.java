package com.example.demo.repos;

import org.springframework.data.jpa.repository.JpaRepository;
import com.example.demo.Cruise;

public interface CruiseRepository extends JpaRepository<Cruise, Integer>{

}
