package com.example.demo.repos;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.example.demo.Booking;

public interface BookingRepository extends JpaRepository<Booking, Integer>{
	
	List<Booking> findByCustomerId(int customerId);
	
	@Modifying
	@Query ("update Booking b set b.status = 'Canceled' where b.bookingId = :id ") 
	void cancelBookingById(@Param("id") int bookingId);
	
	@Query ("select b from Booking b where b.status = 'Reserved' and b.customerId = :id")
	List<Booking> findReservedByCustomerId(@Param("id") int customerId);

}
