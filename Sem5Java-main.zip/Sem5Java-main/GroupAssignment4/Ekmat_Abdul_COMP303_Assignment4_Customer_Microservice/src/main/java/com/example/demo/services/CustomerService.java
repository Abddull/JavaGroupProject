package com.example.demo.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.Customer;
import com.example.demo.repos.CustomerRepository;


@Service
public class CustomerService {

	@Autowired
	CustomerRepository custRepo;

	public Customer addCustomer(Customer cust){
		return custRepo.save(cust);
	}

	public List<Customer> getCustomers() {
		return custRepo.findAll();
	}

	public Customer getCustomerById(int id) {
		 return custRepo.findById(id).get();
	}

	public Customer updateCustomer(Customer cust) {
		return custRepo.save(cust);
	}

	public void deleteCustomer(Customer cust){
		custRepo.delete(cust);
	}
	
	public Customer getCustomerByUsername(String username) {
		return custRepo.findByUsername(username);
	}
}
