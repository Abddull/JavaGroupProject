package com.example.demo.controllers;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.example.demo.Customer;
import com.example.demo.ValidationGroups;
import com.example.demo.services.CustomerService;

@RestController
public class CustomerController {
	
	@Autowired
    CustomerService cusService;

    // Open landing/login/register page
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String index(Customer customer) {
		return "index";
	}

    // Open profile details page
	@GetMapping(value = "/profile")
	public String profile(HttpSession session) {
		if (session.getAttribute("customer") == null) {
			return "index";
		}
		return "profile";
	}
    
    // Check Login credentials for customer
    @GetMapping("/login")
    public String login(@Validated(ValidationGroups.Login.class) Customer loggingCustomer, BindingResult result, Model model, HttpServletRequest request) {
    	if (result.hasErrors()) {
			return "index";
		}
		Customer customer = cusService.getCustomerByUsername(loggingCustomer.getUsername());
		if (customer == null || customer.getPassword().equals(loggingCustomer.getPassword())) {
			model.addAttribute("errorMsg", "Invalid credentials");
			return "index";
		}
		HttpSession session = request.getSession();
		session.setAttribute("customer", customer);
		return "redirect:/history";
    }

    // Logs out current user
	@GetMapping(value = "/logout")
	public String logout(Customer customer, HttpSession session) {
		session.removeAttribute("customer");
		return "index";
	}

    // Add a new Customer
    @PostMapping("/register")
    public String register(@Validated(ValidationGroups.Register.class)  Customer cus, BindingResult result, HttpServletRequest request, Model model) {
    	if(result.hasErrors()) {
			return "register";
		}
		
		cus = cusService.addCustomer(cus);
		HttpSession session = request.getSession();
		session.setAttribute("customer", cus);
		return "redirect:history";
    }

    // Open Update Customer details page
    @RequestMapping("/editprofile")
	public String editProfile(HttpSession session, Model model) {
		if (session.getAttribute("customer") == null) {
			return "index";
		}
		Object customerObject = session.getAttribute("customer");
		if (!(customerObject instanceof Customer)) {
			return "index";
		}
		Customer customer = (Customer)customerObject;
		model.addAttribute("customer", customer);
		return "edit-profile";
	}
    
    // Update Customer details
    @PostMapping("/updateprofile")
    public String updateCustomer(@Validated(ValidationGroups.EditProfile.class) Customer updatedCustomer, BindingResult result, HttpServletRequest request, HttpSession session) {
    	if(result.hasErrors()) {
			return "edit";
		}
    	
		Object customerObject = session.getAttribute("customer");
		if (!(customerObject instanceof Customer)) {
			return "profile";
		}
		
		Customer oldCustomer = (Customer)customerObject;
		oldCustomer = cusService.getCustomerById(oldCustomer.getCustomerId());
		
		//These fields cannot be updated
		updatedCustomer.setCustomerId(oldCustomer.getCustomerId());
		updatedCustomer.setFirstName(oldCustomer.getFirstName());
		updatedCustomer.setLastName(oldCustomer.getLastName());
		updatedCustomer.setUsername(oldCustomer.getUsername());
		updatedCustomer.setPassword(oldCustomer.getPassword());

		cusService.updateCustomer(updatedCustomer);
		session.setAttribute("customer", updatedCustomer);
		return "profile";
    }
    
    
    
    
    
    
    
    
    
 // Check Login credentials for customer
    @PostMapping("/templogin")
    public String templogin(@RequestParam("user")String user, @RequestParam("pass")String pass, BindingResult result, Model model, HttpServletRequest request) {
    	if (result.hasErrors()) {
			return "index";
		}
		Customer customer = cusService.getCustomerByUsername(user);
		if (customer == null || customer.getPassword().equals(pass)) {
			model.addAttribute("errorMsg", "Invalid credentials");
			return "index";
		}
		HttpSession session = request.getSession();
		session.setAttribute("customer", customer);
		return "redirect:/history";
    }
}
