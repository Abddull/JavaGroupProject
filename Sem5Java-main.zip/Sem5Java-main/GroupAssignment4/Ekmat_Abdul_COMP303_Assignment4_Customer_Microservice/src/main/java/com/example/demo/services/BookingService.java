package com.example.demo.services;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.demo.Booking;
import com.example.demo.repos.BookingRepository;

@Service
public class BookingService {

	@Autowired
	BookingRepository bookingRepo;
	
	public void addBooking(Booking booking) {
		bookingRepo.save(booking);
	}
	
	public Booking findById(int bookingId) {
		return bookingRepo.findById(bookingId).get();
	}
	
	public List<Booking> findByCustomerId(int customerId){
		return bookingRepo.findByCustomerId(customerId);
	}
	
	
	public void cancelBookingById(int bookingId) {
		bookingRepo.cancelBookingById(bookingId);
	}
	
	public List<Booking> findReservedByCustomerId(int customerId){
		return bookingRepo.findReservedByCustomerId(customerId);
	}
	
	
}
